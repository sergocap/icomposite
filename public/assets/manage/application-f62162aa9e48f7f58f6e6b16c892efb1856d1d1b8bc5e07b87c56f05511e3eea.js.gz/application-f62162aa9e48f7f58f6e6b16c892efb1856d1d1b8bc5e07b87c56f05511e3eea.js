(function() {
  $(document).on('ready page:load', function() {
    if ($('.js-image_upload').length) {
      init_image_upload();
    }
    return true;
  });

}).call(this);
(function() {


}).call(this);
(function() {


}).call(this);
